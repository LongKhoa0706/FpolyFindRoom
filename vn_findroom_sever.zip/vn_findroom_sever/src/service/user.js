const User = require('../models/user');
const Role = require('../models/role')
const jwt = require('jsonwebtoken')
const { Roles } = require('../models/user');

exports.createUser = async (req_user) => {
}

exports.getIdUser = async function (idUser, callback) {
    User.findOne({ _id: idUser }).then((data) => {
        callback(null, data)
    }).catch((err) => {
        callback(null, err);
        console.log(err)
    });

    User.findOne({ _id: idUser }, callback)
};

// lấy người dùng theo ID
// exports.getIdUser = (req, res) => {
//   // var _idUser = req.params.id ? {_id: req.params.id} : {};
//   User.findOne({_id: req.params.id})
//     .then((user) => {
//       if (!user) {
//         res.status(400).send({
//           api_code: 400,
//           api_status: false,
//           api_message: 'User not found',
//         });
//         return user;
//       } else {
//         res.status(200).send({
//           api_code: 200,
//           api_status: true,
//           api_message: 'Thông tin người dùng',
//           data: user,
//         });
//       }
//     })
//     .catch((err) => {
//       console.log(err);
//     });
// };

exports.updatePhone = async function (idUser, phone, callback) {
    User.findOne({ phone: phone }).then((data) => {
        if (data.length !== 0) {
            callback(data)
        } else {
            User.findOneAndUpdate(idUser, { phone: phone })
                .catch((err) => {
                    callback(err)
                }).then((user) => {
                    if (!user) {
                        // res.status(501).send({
                        //     api_code: 501,
                        //     api_status: false,
                        //     api_message: 'User not found',
                        // })
                        callback(user)
                        return user;
                    } else {
                        callback(user)
                        // res.status(200).send({
                        //     api_code: 200,
                        //     api_status: true,
                        //     api_message: 'Update succress',
                        //     data: user
                        // })
                    }
                })
        }
    })
}

// laay danh sach tat ca chu tro
exports.getListInnkeeper = async (callback) => {
    const role = await Role.findOne({ 'role_name': 'innkeeper' });
    await User.find({ roles: role._id }, function (err, result) {
        callback(err, result)
    }).populate('roles','role_name');
}


