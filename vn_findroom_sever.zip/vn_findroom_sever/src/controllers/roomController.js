const Room = require('../models/room')
const roomService = require('../service/room')
const Validation = require('../includes/validation');
const e = require('express');

exports.addRoom = async (req, res, next) => {
    try {
        let code = await Validation.canDoAction(
            req,
            "createRoom"
        );
        if (code === 200) {
            const room = new Room(req.body)
            room.name = req.body.name
            room.price = req.body.price
            room.address = req.body.address
            room.phone = req.body.phone
            room.description = req.body.description
            room.capacity = req.body.capacity
            room.acreage = req.body.acreage
            room.datepost = req.body.datepost
            room.latitude = req.body.latitude
            room.longitude = req.body.longitude
            room.categoriesRoom = req.body.categoriesRoom
            room.categoriesQuan = req.body.categoriesQuan
            room.iduser = req.body.iduser
            room.images = req.body.images
            room.util = req.body.util

            roomService.createRoom(room, function (error, response) {
                if (response) {
                    res.status(200).send({ statusCode: res.statusCode, success: true, message: "Tạo phòng thành công", data: response });
                } else if (error) {
                    res.status(400).send({ statusCode: res.statusCode, success: false, err: 'Thêm thất bại! ' + error });
                }
            });
        } else {
            res.status(400).send({ statusCode: res.statusCode,message: "Thêm phòng thất bại ", success: false, data: e });
        }
    } catch (e) {
        res.status(400).send({ statusCode: res.statusCode,message: "Thêm phòng thất bại ", success: false, data: e });
    }
}
exports.listDetailRoom = async (req, res) => {
    try {
        let code = await Validation.canDoAction(
            req,
            "getRoomById"
        );
        if (code === 200) {
            roomService.getRoom(req.params.id, function (err, response) {
                if (response) {
                    console.log(response)
                    res.status(200).send({ statusCode: res.statusCode, success: true, data: response });
                } else if (err) {
                    console.log("aaa" + err)
                    res.status(400).send({ statusCode: res.statusCode, success: false, data: err });
                }
            })
        } else {
            res.status(400).send({ statusCode: res.statusCode, success: false, data: e });
        }
    } catch (e) {
        res.status(400).send({ statusCode: res.statusCode, success: false, data: e });
    }
}
exports.listGetAllRoom = async (req, res) => {
    try {
        let code = await Validation.canDoAction(
            req,
            "getAllRoom"
        );
        if (code === 200) {
            roomService.getAll(function (err, response) {
                if (response) {
                    res.status(200).send({ statusCode: res.statusCode, success: true, messages: 'Lấy danh sách thành công!', data: response });
                } else if (err) {
                    res.status(400).send({ statusCode: res.statusCode, success: false, data: err });
                }
            })
        } else {
            res.status(400).send({ statusCode: res.statusCode, success: false, data: e });
        }
    } catch (e) {
        res.status(400).send({ statusCode: res.statusCode, success: false, data: e });
    }
}
exports.listGetRoomForUser = async (req, res) => {
    try {
        let code = await Validation.canDoAction(
            req,
            "getAllRoomForUser"
        );
        if (code === 200) {
            roomService.getRoomForUser(req.params.id, function (err, response) {
                if (response) {
                    res.status(200).send({ statusCode: res.statusCode, success: true, data: response });

                } else {
                    res.status(400).send({ statusCode: res.statusCode, success: true, data: err });
                }
            })
        } else {
            res.status(400).send({ statusCode: res.statusCode, success: false, data: e });
        }
    } catch (e) {
        res.status(400).send({ statusCode: res.statusCode, success: false, data: e });
    }
}