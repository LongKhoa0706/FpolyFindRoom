const express = require('express');
const router  = express.Router();

const userController = require('../controllers/userController');

// import & setting bodyParser
const bodyParser = require('body-parser');
router.use(bodyParser.urlencoded({extended: true}));
router.use(bodyParser.json());

router.post('/creatUser',userController.addUser);
// router.get('/getuser',userController.getUser);
router.put('/updatePhone/:id',userController.updatePhonee)
router.put('/getIdUser/:id',userController.getIdUserr)
router.get('/getListInnkeeper',userController.getListInnkeeper)

module.exports = router
