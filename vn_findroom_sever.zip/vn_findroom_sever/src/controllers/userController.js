const userService = require('../service/user')
const User = require('../models/user')
const Role = require('../models/role')

exports.addUser = async (req, res) => {
    // const user = new User(req.body);
    var user = {};
    user.avatar = req.body.avatar,
    user.name = req.body.name,
    user.email = req.body.email,
    user.phone = req.body.phone,
    user.verifi = req.body.verifi,
    // Set chu tro hay nguoi dung
    user.typeUser = req.body.typeUser,// 1 is innkeeper, 2 is customer
    // Id social
    user.idSocial = req.body.idSocial.trim(),
    user.socialType = req.body.socialType.trim()

    // userService.createUser(user, req.body.uid, function (error, response) {
    //     if (response) {
    //         if (response == 1) {
    //             return res.status(200).send({ statusCode: res.statusCode, success: true, messages: 'Tạo tài khoản thành công', data: response });
    //         } else {
    //             return res.status(200).send({ statusCode: res.statusCode, success: true, messages: 'Cmm Tài khoản đã tồn tại', data: [] });
    //         }
    //     }
    //     if (error) {
    //         return res.status(400).send({ statusCode: res.statusCode, success: false, messages: 'Tài khoản đã tồn tại', data: error });
    //     }
    // })
    // Chia file sap chia di
    var users = "";
    if (user.socialType == 'facebook') {
        users = await User.findOne({ $and: [{ socialType: user.socialType }, { idFacebook: user.idSocial }] });
        if (users) {
            return res.status(200).send({ statusCode: res.statusCode, success: true, messages: 'Cmm Tài khoản đã tồn tại', data: [] });;
        }
        user.idFacebook = user.idSocial
    } else {
        users = await User.findOne({ $and: [{ socialType: user.socialType }, { idGoogle: user.idSocial }] });
        if (users) {
            return res.status(400).send({ statusCode: res.statusCode, success: false, messages: 'Cmm Tài khoản đã tồn tại', data: [] });;
        }
        user.idGoogle = user.idSocial
    }
    if (!users) {
        if (user.typeUser == 1) {
            let roles = await Role.findOne({ role_name: 'innkeeper' });
            user.roles = [roles.id];
        } else {
            let roles = await Role.findOne({ role_name: 'customer' });
            user.roles = [roles.id];
        }
        const newUser = await new User(user).save();

        return res.status(200).send({ statusCode: res.statusCode, success: true, messages: 'Tạo tài khoản thành công', data: newUser });
    } else {
        return res.status(200).send({ statusCode: res.statusCode, success: true, messages: 'Cmm Tài khoản đã tồn tại', data: [] });;
    }
}

exports.getIdUserr = function (req, res) {
    console.log(req.params.id)
    userService.getIdUser(req.params.id, (error, response) => {
        if (response) {
            console.log(response)
            res.status(200).send({ statusCode: res.statusCode, data: response });
        } else {
            res.status(400).send({ statusCode: res.statusCode, error: "Tài khoản không tìm thấy" + error });
        }
    })
}

exports.updatePhonee = async function (req, res) {
    userService.updatePhone(req.params.id, req.body.phone, function (err, response) {
        if (response) {
            console.log(response)
            res.status(201).send({ statusCode: res.statusCode, data: response });
        } else if (err) {
            console.log(err)
            res.status(400).send({ statusCode: res.statusCode, err: 'Tài khoản không tìm thấy ' + err });
        }
    })
}

exports.getListInnkeeper = async function (req, res) {
    userService.getListInnkeeper(function (err,response){
        if(response){
            console.log(response)
            res.status(200).send({statusCode: res.statusCode, message: "Lấy danh sách thành công ",success: true, data: response})
        }else if (err){
            console.log(err)
            res.status(400).send({statusCode: res.statusCode,message: "Lấy danh sách thất bại  ",success:false})
        }
    })
}